var rule = {
  title: '堇夏有声 (有听网)',
  host: 'https://m.ting15.com',
  url: '/fyclass/index_fypage.html',
  homeUrl: '/',
  searchUrl: '/index.php?s=/search-index-wd-**.html',
  searchable: 1,
  quickSearch: 1,
  class_name: '武侠玄幻&恐怖灵异&推理悬疑&都市言情&家庭伦理&官场职场&经典评书&曲艺戏曲&相声小品&助眠音频',
  class_url: 'wuxiaxuanhuan&kongbulingyi&tuilixuanyi&dushiyanqing&jiatinglunli&wenxuemingzhu&jingdianpingshu&quyixiqu&xiangshengxiaopin&yinyue',
  headers: {
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
  },
  推荐: '.tlist a;h3&&Text;img&&src;.desc&&Text;a&&href',
  一级: '.list a||.tlist a||.mlist a;h3&&Text;img&&src;.desc&&Text;a&&href',
  二级: {
    title: '.binfo h1&&Text;.binfo p:eq(0)&&Text',
    img: '.bimg img&&src',
    desc: '.binfo p:eq(2)&&Text;.binfo p:eq(3)&&Text;;.binfo p:eq(1)&&Text;.binfo p:eq(0)&&Text',
    content: '.intro p&&Text',
    tabs: '.playlist h2',
    lists: '.plist a'
  },
  搜索: '.list a||.tlist a;h3&&Text;img&&src;.desc&&Text;a&&href',
  play_parse: true
};
