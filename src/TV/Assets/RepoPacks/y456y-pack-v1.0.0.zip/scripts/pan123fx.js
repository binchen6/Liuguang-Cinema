var rule = {
  title: '123分享社区',
  host: 'https://123panfx.com',
  url: '/?forum-fyclass-fypage.htm',
  homeUrl: '/',
  searchUrl: '/?search-**-1-fypage.htm',
  searchable: 1,
  quickSearch: 1,
  class_name: '电影&剧集&动漫&综艺&纪录片&短剧',
  class_url: '1&2&3&4&5&6',
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/134.0.0.0 Safari/537.36'
  },
  推荐: 'li.thread;a[href*=thread-]&&Text;img&&src;.username&&Text;a[href*=thread-]&&href',
  一级: 'li.thread;a[href*=thread-]&&Text;img&&src;.username&&Text;a[href*=thread-]&&href',
  二级: '*',
  搜索: 'li.thread;a[href*=thread-]&&Text;img&&src;.username&&Text;a[href*=thread-]&&href',
  play_parse: true
};
